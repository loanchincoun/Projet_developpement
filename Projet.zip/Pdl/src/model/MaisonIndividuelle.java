package model;


public class MaisonIndividuelle extends BienImmobilier {

	private boolean cave;
	private boolean sousSol;
	private boolean jardin;
	private double superficieJardin;
	private boolean terrain;
	private double superficieTerrain;
	private boolean cour;
	private double superficieCour;

	
	
	public MaisonIndividuelle(double idBien,double idBailleur, String adresse,
			double superficieHabitable, double nombreDeChambre, String indicateur, boolean balcon,
			double superficieBalcon, boolean terasse, double superficieTerasse, double anneeDeConstructionDuBatiment,
			String typeDeChauffage, String attestationAssurance, String etatDesLieux, boolean cave, boolean sousSol,
			boolean jardin, double superficieJardin, boolean terrain, double superficieTerrain, boolean cour,
			double superficieCour) {
		super(idBien,idBailleur, adresse, superficieHabitable, nombreDeChambre, indicateur, balcon,
				superficieBalcon, terasse, superficieTerasse, anneeDeConstructionDuBatiment, typeDeChauffage,
				attestationAssurance, etatDesLieux);
		this.cave = cave;
		this.sousSol = sousSol;
		this.jardin = jardin;
		this.superficieJardin = superficieJardin;
		this.terrain = terrain;
		this.superficieTerrain = superficieTerrain;
		this.cour = cour;
		this.superficieCour = superficieCour;
	}



	public boolean isCave() {
		return cave;
	}



	public void setCave(boolean cave) {
		this.cave = cave;
	}



	public boolean isSousSol() {
		return sousSol;
	}



	public void setSousSol(boolean sousSol) {
		this.sousSol = sousSol;
	}



	public boolean isJardin() {
		return jardin;
	}



	public void setJardin(boolean jardin) {
		this.jardin = jardin;
	}



	public double getSuperficieJardin() {
		return superficieJardin;
	}



	public void setSuperficieJardin(double superficieJardin) {
		this.superficieJardin = superficieJardin;
	}



	public boolean isTerrain() {
		return terrain;
	}



	public void setTerrain(boolean terrain) {
		this.terrain = terrain;
	}



	public double getSuperficieTerrain() {
		return superficieTerrain;
	}



	public void setSuperficieTerrain(double superficieTerrain) {
		this.superficieTerrain = superficieTerrain;
	}



	public boolean isCour() {
		return cour;
	}



	public void setCour(boolean cour) {
		this.cour = cour;
	}



	public double getSuperficieCour() {
		return superficieCour;
	}



	public void setSuperficieCour(double superficieCour) {
		this.superficieCour = superficieCour;
	}
	
	

	}

