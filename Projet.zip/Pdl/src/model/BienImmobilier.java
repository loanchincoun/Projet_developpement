package model;

public class BienImmobilier {

	private double idBien;
	private double idBailleur;
	private String adresse;
	private double superficieHabitable;
	private double nombreDeChambre;
	private String indicateur;
	private boolean balcon;
	private double superficieBalcon;
	private boolean terasse;
	private double SuperficieTerasse;
	private double anneeDeConstructionDuBatiment;
	private String typeDeChauffage;
	private String attestationAssurance;
	private String etatDesLieux;
	public BienImmobilier(double idBien,double idBailleur, String adresse,
		double superficieHabitable, double nombreDeChambre, String indicateur, boolean balcon, double superficieBalcon,
		boolean terasse, double superficieTerasse, double anneeDeConstructionDuBatiment, String typeDeChauffage,
		String attestationAssurance, String etatDesLieux) {
	this.idBien = idBien;
	this.idBailleur=idBailleur;
	this.adresse = adresse;
	this.superficieHabitable = superficieHabitable;
	this.nombreDeChambre = nombreDeChambre;
	this.indicateur = indicateur;
	this.balcon = balcon;
	this.superficieBalcon = superficieBalcon;
	this.terasse = terasse;
	this.SuperficieTerasse = superficieTerasse;
	this.anneeDeConstructionDuBatiment = anneeDeConstructionDuBatiment;
	this.typeDeChauffage = typeDeChauffage;
	this.attestationAssurance = attestationAssurance;
	this.etatDesLieux = etatDesLieux;
}
	public double getIdBien() {
		return idBien;
}
	public void setIdBien(double idBien) {
		this.idBien = idBien;
}

	public double getIdBailleur() {
		return idBailleur;
	}
	public void setIdBailleur(double idBailleur) {
		this.idBailleur = idBailleur;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public double getSuperficieHabitable() {
		return superficieHabitable;
	}
	public void setSuperficieHabitable(double superficieHabitable) {
		this.superficieHabitable = superficieHabitable;
	}
	public double getNombreDeChambre() {
		return nombreDeChambre;
	}
	public void setNombreDeChambre(double nombreDeChambre) {
		this.nombreDeChambre = nombreDeChambre;
	}
	public String getIndicateur() {
		return indicateur;
	}
	public void setIndicateur(String indicateur) {
		this.indicateur = indicateur;
	}
	public boolean isBalcon() {
		return balcon;
	}
	public void setBalcon(boolean balcon) {
		this.balcon = balcon;
	}
	public double getSuperficieBalcon() {
		return superficieBalcon;
	}
	public void setSuperficieBalcon(double superficieBalcon) {
		this.superficieBalcon = superficieBalcon;
	}
	public boolean isTerasse() {
		return terasse;
	}
	public void setTerasse(boolean terasse) {
		this.terasse = terasse;
	}
	public double getSuperficieTerasse() {
		return SuperficieTerasse;
	}
	public void setSuperficieTerasse(double superficieTerasse) {
		SuperficieTerasse = superficieTerasse;
	}
	public double getAnneeDeConstructionDuBatiment() {
		return anneeDeConstructionDuBatiment;
	}
	public void setAnneeDeConstructionDuBatiment(double anneeDeConstructionDuBatiment) {
		this.anneeDeConstructionDuBatiment = anneeDeConstructionDuBatiment;
	}
	public String getTypeDeChauffage() {
		return typeDeChauffage;
	}
	public void setTypeDeChauffage(String typeDeChauffage) {
		this.typeDeChauffage = typeDeChauffage;
	}
	public String getAttestationAssurance() {
		return attestationAssurance;
	}
	public void setAttestationAssurance(String attestationAssurance) {
		this.attestationAssurance = attestationAssurance;
	}
	public String getEtatDesLieux() {
		return etatDesLieux;
	}
	public void setEtatDesLieux(String etatDesLieux) {
		this.etatDesLieux = etatDesLieux;
	}
}