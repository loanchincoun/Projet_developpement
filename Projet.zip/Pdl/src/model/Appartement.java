package model;


public class Appartement extends BienImmobilier {

	private double etage;
	private double numeroAppartement;
	
	
	
	public Appartement(double idBien,double idBailleur, String adresse,
			double superficieHabitable, double nombreDeChambre, String indicateur, boolean balcon,
			double superficieBalcon, boolean terasse, double superficieTerasse, double anneeDeConstructionDuBatiment,
			String typeDeChauffage, String attestationAssurance, String etatDesLieux,double etage,double numeroAppartement) {
		super(idBien,idBailleur, adresse, superficieHabitable, nombreDeChambre, indicateur, balcon,
				superficieBalcon, terasse, superficieTerasse, anneeDeConstructionDuBatiment, typeDeChauffage,
				attestationAssurance, etatDesLieux);
		this.etage = etage;
		this.numeroAppartement = numeroAppartement;
		// TODO Auto-generated constructor stub
	}







	public double getEtage() {
		return etage;
	}



	public void setEtage(double etage) {
		this.etage = etage;
	}



	public double getNumeroAppartement() {
		return numeroAppartement;
	}



	public void setNumeroAppartement(double numeroAppartement) {
		this.numeroAppartement = numeroAppartement;
	}
	
	
}