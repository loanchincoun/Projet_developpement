package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.io.File;
import java.io.IOException;
 
import javax.swing.JFileChooser;
public class test {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
            // création de la boîte de dialogue
            JFileChooser dialogue = new JFileChooser();
             
            // affichage
            dialogue.showOpenDialog(null);
             
            // récupération du fichier sélectionné
            System.out.println("Fichier choisi : " + dialogue.getSelectedFile());
        }
}
