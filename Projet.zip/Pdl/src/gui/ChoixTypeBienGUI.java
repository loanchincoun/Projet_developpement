 package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import Interfaces_graphiques.Gerer_bien;
import Interfaces_graphiques.Gerer_maison;
import Interfaces_graphiques.Gérer_locataire;
import Interfaces_graphiques.Page_connexion;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChoixTypeBienGUI {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChoixTypeBienGUI window = new ChoixTypeBienGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChoixTypeBienGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Quel type de bien?");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel.setBounds(123, 18, 202, 25);
		frame.getContentPane().add(lblNewLabel);
		
		JButton chApp = new JButton("Appartement");
		chApp.setFont(new Font("Lucida Grande", Font.BOLD, 17));
		chApp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Gerer_bien window = new Gerer_bien(); 
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				frame.dispose();
			}
		});
		chApp.setBounds(36, 118, 140, 39);
		frame.getContentPane().add(chApp);
		
		JButton chMI = new JButton("Maison Individuelle");
		chMI.setFont(new Font("Lucida Grande", Font.BOLD, 17));
		chMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Gerer_maison window = new Gerer_maison(); 
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				frame.dispose();
			}
		});
		chMI.setBounds(232, 120, 195, 34);
		frame.getContentPane().add(chMI);
		
		JButton botRetu = new JButton("retour");
		botRetu.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		botRetu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Page_connexion window = new Page_connexion();
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
				frame.dispose();
			}
		});
		botRetu.setBounds(17, 232, 117, 29);
		frame.getContentPane().add(botRetu);
	}
}
