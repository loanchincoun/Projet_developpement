package gui;

import java.awt.EventQueue;
import gui.MaisonIndividuelleGUI2;
import model.Appartement;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Dao.AppartementDAO;
import Interfaces_graphiques.Page_connexion;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JComboBox;

public class AppartementGUI1 {

	public JFrame frame;
	private JTextField txtSupBal;
	private JTextField txtSupHab;
	private JTextField txtNRoom;
	private JTextField txtSupTer;
	private JTextField txtAnCon;
	private JTextField txtTyChuf;
	private JTextField txtEtage;
	private JTextField txtNApp;
	private JTextField txtId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppartementGUI1 window = new AppartementGUI1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppartementGUI1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		AppartementDAO nwd= new AppartementDAO();
		
		JLabel reTitle = new JLabel("Ajout d'un appartement");
		reTitle.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		reTitle.setBounds(214, 6, 202, 16);
		frame.getContentPane().add(reTitle);
		
		JLabel reId = new JLabel("identifiant du bien: ");
		reId.setBounds(24, 40, 130, 16);
		frame.getContentPane().add(reId);
		
		JLabel reAdr = new JLabel("Adresse:");
		reAdr.setBounds(24, 78, 61, 16);
		frame.getContentPane().add(reAdr);
		
		JLabel reSupHab = new JLabel("Superficie habitable:");
		reSupHab.setBounds(24, 194, 137, 16);
		frame.getContentPane().add(reSupHab);
		
		JLabel reNRoom = new JLabel("Nombre de chambres:");
		reNRoom.setBounds(24, 220, 150, 16);
		frame.getContentPane().add(reNRoom);
		
		JLabel reMeu = new JLabel("Meubles: ");
		reMeu.setBounds(24, 248, 61, 16);
		frame.getContentPane().add(reMeu);
		
		JLabel reBal = new JLabel("Balcon:");
		reBal.setBounds(279, 78, 51, 16);
		frame.getContentPane().add(reBal);
		
		JLabel reSupBal = new JLabel("Superficie du balcon:");
		reSupBal.setBounds(279, 106, 137, 16);
		frame.getContentPane().add(reSupBal);
		
		JLabel reTer = new JLabel("Terasse:");
		reTer.setBounds(279, 138, 61, 16);
		frame.getContentPane().add(reTer);
		
		JLabel reSupTer = new JLabel("Superficie de la terasse:");
		reSupTer.setBounds(279, 166, 150, 16);
		frame.getContentPane().add(reSupTer);
		
		JLabel reAnCon = new JLabel("Année de costruction:");
		reAnCon.setBounds(279, 194, 144, 16);
		frame.getContentPane().add(reAnCon);
		
		JLabel reTyChuf = new JLabel("Type de chauffage:");
		reTyChuf.setBounds(279, 222, 137, 16);
		frame.getContentPane().add(reTyChuf);
		
		JRadioButton ouiBal = new JRadioButton("Oui");
		ouiBal.setBounds(323, 74, 61, 23);
		frame.getContentPane().add(ouiBal);
		
		JRadioButton nonBal = new JRadioButton("Non");
		nonBal.setBounds(396, 74, 61, 23);
		frame.getContentPane().add(nonBal);
		
		ButtonGroup bal = new ButtonGroup();
		bal.add(ouiBal);
		bal.add(nonBal);
		
		JRadioButton ouiTer = new JRadioButton("Oui");
		ouiTer.setBounds(334, 134, 61, 23);
		frame.getContentPane().add(ouiTer);
		
		JRadioButton nonTer = new JRadioButton("Non");
		nonTer.setBounds(396, 134, 61, 23);
		frame.getContentPane().add(nonTer);
		
		ButtonGroup ter = new ButtonGroup();
		ter.add(ouiTer);
		ter.add(nonTer);
		
		txtSupBal = new JTextField();
		txtSupBal.setBounds(419, 101, 61, 26);
		frame.getContentPane().add(txtSupBal);
		txtSupBal.setColumns(10);
		
		txtSupHab = new JTextField();
		txtSupHab.setBounds(154, 189, 95, 26);
		frame.getContentPane().add(txtSupHab);
		txtSupHab.setColumns(10);
		
		txtNRoom = new JTextField();
		txtNRoom.setBounds(164, 215, 74, 26);
		frame.getContentPane().add(txtNRoom);
		txtNRoom.setColumns(10);
		
		txtSupTer = new JTextField();
		txtSupTer.setBounds(431, 164, 74, 26);
		frame.getContentPane().add(txtSupTer);
		txtSupTer.setColumns(10);
		
		txtAnCon = new JTextField();
		txtAnCon.setBounds(419, 189, 83, 26);
		frame.getContentPane().add(txtAnCon);
		txtAnCon.setColumns(10);
		
		txtTyChuf = new JTextField();
		txtTyChuf.setBounds(398, 217, 130, 26);
		frame.getContentPane().add(txtTyChuf);
		txtTyChuf.setColumns(10);

		
		JButton botRetu = new JButton("Retour");
		botRetu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Page_connexion window = new Page_connexion();
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
				frame.dispose();
			}
		});
		botRetu.setBounds(367, 378, 117, 29);
		frame.getContentPane().add(botRetu);
		
		JLabel reEtage = new JLabel("Etage:");
		reEtage.setBounds(24, 138, 43, 16);
		frame.getContentPane().add(reEtage);
		
		txtEtage = new JTextField();
		txtEtage.setBounds(79, 131, 130, 26);
		frame.getContentPane().add(txtEtage);
		txtEtage.setColumns(10);
		
		JLabel reNApp = new JLabel("N° Appartement:");
		reNApp.setBounds(24, 166, 117, 16);
		frame.getContentPane().add(reNApp); 
		
		txtNApp = new JTextField();
		txtNApp.setBounds(137, 161, 104, 26);
		frame.getContentPane().add(txtNApp);
		txtNApp.setColumns(10);
		
		ButtonGroup esc = new ButtonGroup();
		
		JTextArea txtAdr = new JTextArea();
		txtAdr.setBounds(90, 68, 159, 55);
		frame.getContentPane().add(txtAdr);
		
		JTextArea txtMeu = new JTextArea();
		txtMeu.setBounds(97, 244, 159, 71);
		frame.getContentPane().add(txtMeu);
		
		txtId = new JTextField();
		txtId.setBounds(162, 35, 74, 26);
		frame.getContentPane().add(txtId);
		txtId.setColumns(10);
		
		JLabel reIdB = new JLabel("Identifiant du bailleur:");
		reIdB.setBounds(278, 40, 150, 16);
		frame.getContentPane().add(reIdB);
		
		JLabel reChAss = new JLabel("Chemin du ficher de l'attestation assurance:");
		reChAss.setBounds(279, 248, 283, 16);
		frame.getContentPane().add(reChAss);
		
		JTextArea txtChAss = new JTextArea();
		txtChAss.setBounds(279, 276, 334, 42);
		frame.getContentPane().add(txtChAss);
		
		JLabel reChE = new JLabel("Chemin du ficher de l'etat de lieu:");
		reChE.setBounds(24, 327, 225, 16);
		frame.getContentPane().add(reChE);
		
		JTextArea txtChE = new JTextArea();
		txtChE.setBounds(24, 355, 253, 42);
		frame.getContentPane().add(txtChE);
		
		JComboBox listId = new JComboBox();
		listId.setBounds(431, 36, 74, 20);
		frame.getContentPane().add(listId);
		
		ArrayList<Appartement> list = nwd.getList();
		for (Appartement s : list) {
			listId.addItem(s.getIdBailleur());
		}
		
		JButton botVal = new JButton("Valider");
		botVal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appartement ap = new Appartement(Double.parseDouble(txtId.getText()),
						Double.parseDouble(String.valueOf( listId.getSelectedItem())),
						txtAdr.getText(),
						Double.parseDouble(txtSupHab.getText()),
						Double.parseDouble(txtNRoom.getText()),
						txtMeu.getText(),
						ouiBal.isSelected(),
						Double.parseDouble(txtSupBal.getText()),
						ouiTer.isSelected(),
						Double.parseDouble( txtSupTer.getText()),
						Double.parseDouble(txtAnCon.getText()),
						txtTyChuf.getText(),
						txtChAss.getText(),
						txtChE.getText(),
						Double.parseDouble(txtEtage.getText()),
						Double.parseDouble(txtNApp.getText()));
				AppartementDAO nwd= new AppartementDAO();
				String mess = nwd.add(ap);
				JOptionPane.showMessageDialog(new JFrame(),mess,"Resultat",JOptionPane.PLAIN_MESSAGE);
		//		AppartementGUI2 nw = new AppartementGUI2();
		//		nw.main();
			//	frame.dispose();
			}
		});
		botVal.setBounds(496, 378, 117, 29);
		frame.getContentPane().add(botVal);
		

		

	}
}
