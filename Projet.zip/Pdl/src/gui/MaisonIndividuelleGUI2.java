package gui;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Dao.MaisonIndividuelleDAO;
import Interfaces_graphiques.Page_connexion;
import model.Appartement;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import java.awt.Font;
import model.MaisonIndividuelle;
import Dao.MaisonIndividuelleDAO;

public class MaisonIndividuelleGUI2 {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MaisonIndividuelleGUI2 window = new MaisonIndividuelleGUI2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MaisonIndividuelleGUI2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 632, 537);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		MaisonIndividuelleDAO nwd = new MaisonIndividuelleDAO();

		
		JLabel reTitle = new JLabel("Modification d'une maison individuelle");
		reTitle.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		reTitle.setBounds(97, 6, 371, 22);
		frame.getContentPane().add(reTitle);
		
		JLabel reId = new JLabel("identifiant du bien: ");
		reId.setBounds(24, 40, 129, 16);
		frame.getContentPane().add(reId);
		
		JLabel reAdr = new JLabel("Adresse:");
		reAdr.setBounds(24, 97, 61, 16);
		frame.getContentPane().add(reAdr);
		
		JLabel reSupHab = new JLabel("Superficie habitable:");
		reSupHab.setBounds(24, 194, 137, 16);
		frame.getContentPane().add(reSupHab);
		
		JLabel reNRoom = new JLabel("Nombre de chambres:");
		reNRoom.setBounds(24, 220, 150, 16);
		frame.getContentPane().add(reNRoom);
		
		JLabel reMeu = new JLabel("Meubles: ");
		reMeu.setBounds(24, 248, 61, 16);
		frame.getContentPane().add(reMeu);
		
		JLabel reBal = new JLabel("Balcon:");
		reBal.setBounds(278, 40, 51, 16);
		frame.getContentPane().add(reBal);
		
		JLabel reSupBal = new JLabel("Superficie du balcon:");
		reSupBal.setBounds(278, 78, 137, 16);
		frame.getContentPane().add(reSupBal);
		
		JLabel reTer = new JLabel("Terasse:");
		reTer.setBounds(278, 106, 61, 16);
		frame.getContentPane().add(reTer);
		
		JLabel reSupTer = new JLabel("Superficie de la terasse:");
		reSupTer.setBounds(278, 134, 150, 16);
		frame.getContentPane().add(reSupTer);
		
		JLabel reAnCon = new JLabel("Année de costruction:");
		reAnCon.setBounds(24, 138, 144, 16);
		frame.getContentPane().add(reAnCon);
		
		JLabel reTyChuf = new JLabel("Type de chauffage:");
		reTyChuf.setBounds(24, 166, 137, 16);
		frame.getContentPane().add(reTyChuf);
		
		JRadioButton ouiBal = new JRadioButton("Oui");
		ouiBal.setBounds(334, 40, 61, 23);
		frame.getContentPane().add(ouiBal);
		
		JRadioButton nonBal = new JRadioButton("Non");
		nonBal.setBounds(396, 40, 61, 23);
		frame.getContentPane().add(nonBal);
		
		ButtonGroup bal = new ButtonGroup();
		bal.add(ouiBal);
		bal.add(nonBal);
		
		JRadioButton ouiTer = new JRadioButton("Oui");
		ouiTer.setBounds(334, 106, 61, 23);
		frame.getContentPane().add(ouiTer);
		
		JRadioButton nonTer = new JRadioButton("Non");
		nonTer.setBounds(396, 106, 61, 23);
		frame.getContentPane().add(nonTer);
		
		ButtonGroup ter = new ButtonGroup();
		ter.add(ouiTer);
		ter.add(nonTer);
		
		
		
		JButton botRetu = new JButton("Retour");
		botRetu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Page_connexion window = new Page_connexion();
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
				frame.dispose();
			}
		});
		botRetu.setBounds(379, 480, 117, 29);
		frame.getContentPane().add(botRetu);
		
		JEditorPane txtAdr = new JEditorPane();
		txtAdr.setBounds(97, 97, 165, 29);
		frame.getContentPane().add(txtAdr);
		
		JEditorPane txtSupHab = new JEditorPane();
		txtSupHab.setBounds(164, 194, 101, 16);
		frame.getContentPane().add(txtSupHab);
		
		JEditorPane txtNRoom = new JEditorPane();
		txtNRoom.setBounds(166, 220, 101, 16);
		frame.getContentPane().add(txtNRoom);
		
		JEditorPane txtMeu = new JEditorPane();
		txtMeu.setBounds(97, 248, 165, 56);
		frame.getContentPane().add(txtMeu);
		
		JEditorPane txtSupBal = new JEditorPane();
		txtSupBal.setBounds(418, 78, 78, 16);
		frame.getContentPane().add(txtSupBal);
		
		JEditorPane txtSupTer = new JEditorPane();
		txtSupTer.setBounds(440, 134, 87, 23);
		frame.getContentPane().add(txtSupTer);
		
		JEditorPane txtAnCon = new JEditorPane();
		txtAnCon.setBounds(166, 138, 101, 16);
		frame.getContentPane().add(txtAnCon);
		
		JEditorPane txtTyChuf = new JEditorPane();
		txtTyChuf.setBounds(150, 166, 117, 16);
		frame.getContentPane().add(txtTyChuf);
		
		JLabel reJardin = new JLabel("Jardin:");
		reJardin.setBounds(278, 166, 40, 16);
		frame.getContentPane().add(reJardin);
		
		JLabel reSupCave = new JLabel("Superficie du jardin:");
		reSupCave.setBounds(278, 194, 137, 16);
		frame.getContentPane().add(reSupCave);
		
		JLabel reTera = new JLabel("Terrain:");
		reTera.setBounds(278, 220, 51, 16);
		frame.getContentPane().add(reTera);
		
		JLabel reSupTera = new JLabel("Superficie du terrain:");
		reSupTera.setBounds(278, 248, 137, 16);
		frame.getContentPane().add(reSupTera);
		
		JLabel reCour = new JLabel("Cour:");
		reCour.setBounds(278, 278, 61, 16);
		frame.getContentPane().add(reCour);
		
		JLabel reSupCour = new JLabel("Superficie de la cour:");
		reSupCour.setBounds(278, 306, 137, 16);
		frame.getContentPane().add(reSupCour);
		
		JRadioButton ouiJardin = new JRadioButton("Oui");
		ouiJardin.setBounds(316, 162, 61, 23);
		frame.getContentPane().add(ouiJardin);
		
		JRadioButton nonJardin = new JRadioButton("Non");
		nonJardin.setBounds(387, 162, 61, 23);
		frame.getContentPane().add(nonJardin);
		
		ButtonGroup jardin = new ButtonGroup();
		jardin.add(ouiJardin);
		jardin.add(nonJardin);
		
		JRadioButton ouiTera = new JRadioButton("Oui");
		ouiTera.setBounds(334, 216, 61, 23);
		frame.getContentPane().add(ouiTera);
		
		JRadioButton nonTera = new JRadioButton("Non");
		nonTera.setBounds(396, 216, 61, 23);
		frame.getContentPane().add(nonTera);
		
		ButtonGroup tera = new ButtonGroup();
		tera.add(ouiTera);
		tera.add(nonTera);
		
		JRadioButton ouiCour = new JRadioButton("Oui");
		ouiCour.setBounds(316, 276, 61, 23);
		frame.getContentPane().add(ouiCour);
		
		JRadioButton nonCour = new JRadioButton("Non");
		nonCour.setBounds(386, 276, 61, 23);
		frame.getContentPane().add(nonCour);
		
		ButtonGroup cour = new ButtonGroup();
		cour.add(ouiCour);
		cour.add(nonCour);
		
		JEditorPane txtSupJardin = new JEditorPane();
		txtSupJardin.setBounds(410, 194, 101, 16);
		frame.getContentPane().add(txtSupJardin);
		
		JEditorPane txtSupTera = new JEditorPane();
		txtSupTera.setBounds(410, 248, 101, 16);
		frame.getContentPane().add(txtSupTera);
		
		JEditorPane txtSupCour = new JEditorPane();
		txtSupCour.setBounds(410, 306, 101, 16);
		frame.getContentPane().add(txtSupCour);
		

		
		JLabel reCave = new JLabel("Cave:");
		reCave.setBounds(24, 318, 61, 16);
		frame.getContentPane().add(reCave);
		
		JLabel reSS = new JLabel("Soussol:");
		reSS.setBounds(24, 349, 61, 16);
		frame.getContentPane().add(reSS);
		
		JRadioButton ouiCave = new JRadioButton("Oui");
		ouiCave.setBounds(86, 316, 61, 23);
		frame.getContentPane().add(ouiCave);
		
		JRadioButton ouiSS = new JRadioButton("Oui");
		ouiSS.setBounds(86, 345, 61, 23);
		frame.getContentPane().add(ouiSS);
		
		JRadioButton nonSS = new JRadioButton("Non");
		nonSS.setBounds(150, 345, 61, 23);
		frame.getContentPane().add(nonSS);
		
		JRadioButton nonCave = new JRadioButton("Non");
		nonCave.setBounds(150, 316, 61, 23);
		frame.getContentPane().add(nonCave);
		
		ButtonGroup cave = new ButtonGroup();
		cave.add(ouiCave);
		cave.add(nonCave);
		
		ButtonGroup ss = new ButtonGroup();
		ss.add(ouiSS);
		ss.add(nonSS);
		
		JLabel reIdB = new JLabel("Identifiant du bailleur:");
		reIdB.setBounds(24, 69, 150, 16);
		frame.getContentPane().add(reIdB);
		
		JLabel txtIdB = new JLabel("");
		txtIdB.setBounds(190, 69, 61, 16);
		frame.getContentPane().add(txtIdB);
		
		JLabel reChAss = new JLabel("Chemin du ficher de l'attestation assurance:");
		reChAss.setBounds(24, 380, 283, 16);
		frame.getContentPane().add(reChAss);
		
		JTextArea txtChAss = new JTextArea();
		txtChAss.setBounds(316, 365, 297, 42);
		frame.getContentPane().add(txtChAss);
		
		JLabel reChE = new JLabel("Chemin du ficher de l'etat de lieu:");
		reChE.setBounds(24, 436, 225, 16);
		frame.getContentPane().add(reChE);
		
		JTextArea txtChE = new JTextArea();
		txtChE.setBounds(316, 426, 287, 42);
		frame.getContentPane().add(txtChE);
		
		JComboBox listId = new JComboBox();
		listId.setBounds(151, 36, 87, 27);
		frame.getContentPane().add(listId);
		
		ArrayList<MaisonIndividuelle> list = nwd.getList();
		for (MaisonIndividuelle s : list) {
			listId.addItem(s.getIdBien());
		}
		listId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double id= Double.parseDouble(String.valueOf( listId.getSelectedItem()));
				MaisonIndividuelle app1 = nwd.get(id);
				txtAdr.setText(app1.getAdresse());
				txtSupHab.setText(String.valueOf(app1.getSuperficieHabitable()));
				txtNRoom.setText(String.valueOf(app1.getNombreDeChambre()));
				txtMeu.setText(String.valueOf(app1.getIndicateur()));
				txtSupBal.setText(String.valueOf(app1.getSuperficieBalcon()));
				txtSupTer.setText(String.valueOf(app1.getSuperficieTerasse()));
				txtAnCon.setText(String.valueOf(app1.getAnneeDeConstructionDuBatiment()));
				txtTyChuf.setText(String.valueOf(app1.getTypeDeChauffage()));
				txtIdB.setText(String.valueOf(app1.getIdBailleur()));
				txtSupTera.setText(String.valueOf(app1.getSuperficieTerrain()));
				txtSupJardin.setText(String.valueOf(app1.getSuperficieJardin()));
				txtSupCour.setText(String.valueOf(app1.getSuperficieCour()));
				ouiCave.setSelected(app1.isCave());
				ouiSS.setSelected(app1.isSousSol());
				txtChE.setText(app1.getEtatDesLieux());
				txtChAss.setText(app1.getAttestationAssurance());
			}					
			});
		
		JButton botVal = new JButton("Valider");
		botVal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MaisonIndividuelle ap = new MaisonIndividuelle(Double.parseDouble(String.valueOf( listId.getSelectedItem())),
						Double.parseDouble(String.valueOf( listId.getSelectedItem())),
						txtAdr.getText(),
						Double.parseDouble(txtSupHab.getText()),
						Double.parseDouble(txtNRoom.getText()),
						txtMeu.getText(),
						ouiBal.isSelected(),
						Double.parseDouble(txtSupBal.getText()),
						ouiTer.isSelected(),
						Double.parseDouble( txtSupTer.getText()),
						Double.parseDouble(txtAnCon.getText()),
						txtTyChuf.getText(),
						txtChAss.getText(),
						txtChE.getText(),
						ouiCave.isSelected(),
						ouiSS.isSelected(),
						ouiJardin.isSelected(),
						Double.parseDouble(txtSupJardin.getText()),
						ouiTera.isSelected(),
						Double.parseDouble(txtSupTera.getText()),
						ouiCour.isSelected(),
						Double.parseDouble(txtSupCour.getText())
						);
				String mess = nwd.add(ap);
				JOptionPane.showMessageDialog(new JFrame(),mess,"Resultat",JOptionPane.PLAIN_MESSAGE);
			}
		});
		botVal.setBounds(509, 480, 117, 29);
		frame.getContentPane().add(botVal);
		

		
	}
}