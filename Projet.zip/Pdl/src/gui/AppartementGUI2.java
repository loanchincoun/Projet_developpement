package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Dao.AppartementDAO;
import Interfaces_graphiques.Page_connexion;
import model.Appartement;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import java.awt.Font;

public class AppartementGUI2 {

	public JFrame frame;

	/**
	 * Launch the application. 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppartementGUI2 window = new AppartementGUI2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppartementGUI2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 621, 436);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		AppartementDAO nwd= new AppartementDAO();
		JLabel reTitle = new JLabel("Modification des informations de l'appartement");
		reTitle.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		reTitle.setBounds(97, 6, 371, 22);
		frame.getContentPane().add(reTitle);
		
		JLabel reId = new JLabel("identifiant du bien: ");
		reId.setBounds(24, 40, 137, 16);
		frame.getContentPane().add(reId);
		
		JLabel reAdr = new JLabel("Adresse:");
		reAdr.setBounds(24, 78, 61, 16);
		frame.getContentPane().add(reAdr);
		
		JLabel reSupHab = new JLabel("Superficie habitable:");
		reSupHab.setBounds(24, 194, 137, 16);
		frame.getContentPane().add(reSupHab);
		
		JLabel reNRoom = new JLabel("Nombre de chambres:");
		reNRoom.setBounds(24, 220, 150, 16);
		frame.getContentPane().add(reNRoom);
		
		JLabel reMeu = new JLabel("Meubles: ");
		reMeu.setBounds(24, 248, 61, 16);
		frame.getContentPane().add(reMeu);
		
		JLabel reBal = new JLabel("Balcon:");
		reBal.setBounds(279, 78, 51, 16);
		frame.getContentPane().add(reBal);
		
		JLabel reSupBal = new JLabel("Superficie du balcon:");
		reSupBal.setBounds(279, 106, 137, 16);
		frame.getContentPane().add(reSupBal);
		
		JLabel reTer = new JLabel("Terasse:");
		reTer.setBounds(279, 138, 61, 16);
		frame.getContentPane().add(reTer);
		
		JLabel reSupTer = new JLabel("Superficie de la terasse:");
		reSupTer.setBounds(279, 166, 150, 16);
		frame.getContentPane().add(reSupTer);
		
		JLabel reAnCon = new JLabel("Année de costruction:");
		reAnCon.setBounds(279, 194, 144, 16);
		frame.getContentPane().add(reAnCon);
		
		JLabel reTyChuf = new JLabel("Type de chauffage:");
		reTyChuf.setBounds(279, 222, 137, 16);
		frame.getContentPane().add(reTyChuf);
		
		JRadioButton ouiBal = new JRadioButton("Oui");
		ouiBal.setBounds(323, 74, 61, 23);
		frame.getContentPane().add(ouiBal);
		
		JRadioButton nonBal = new JRadioButton("Non");
		nonBal.setBounds(396, 74, 61, 23);
		frame.getContentPane().add(nonBal);
		
		ButtonGroup Bal = new ButtonGroup();
		Bal.add(ouiBal);
		Bal.add(nonBal);
		
		JRadioButton ouiTer = new JRadioButton("Oui");
		ouiTer.setBounds(334, 134, 61, 23);
		frame.getContentPane().add(ouiTer);
		
		JRadioButton nonTer = new JRadioButton("Non");
		nonTer.setBounds(396, 134, 61, 23);
		frame.getContentPane().add(nonTer);
		
		ButtonGroup Ter = new ButtonGroup();
		Bal.add(ouiTer);
		Bal.add(nonTer);
	
		
		JButton botRetu = new JButton("Retour");
		botRetu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Page_connexion window = new Page_connexion();
					window.frame.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
				frame.dispose();
			}
		});
		botRetu.setBounds(377, 379, 117, 29);
		frame.getContentPane().add(botRetu);
		
		JLabel reEtage = new JLabel("Etage:");
		reEtage.setBounds(24, 138, 43, 16);
		frame.getContentPane().add(reEtage);
		
		JLabel reNApp = new JLabel("N° Appartement:");
		reNApp.setBounds(24, 166, 117, 16);
		frame.getContentPane().add(reNApp);
		

		
		JEditorPane txtAdr = new JEditorPane();
		txtAdr.setBounds(97, 78, 165, 44);
		frame.getContentPane().add(txtAdr);
		
		JEditorPane txtEtage = new JEditorPane();
		txtEtage.setBounds(73, 134, 101, 23);
		frame.getContentPane().add(txtEtage);
		
		JEditorPane txtNApp = new JEditorPane();
		txtNApp.setBounds(134, 166, 117, 16);
		frame.getContentPane().add(txtNApp);
		
		JEditorPane txtSupHab = new JEditorPane();
		txtSupHab.setBounds(164, 194, 101, 16);
		frame.getContentPane().add(txtSupHab);
		
		JEditorPane txtNRoom = new JEditorPane();
		txtNRoom.setBounds(166, 220, 101, 16);
		frame.getContentPane().add(txtNRoom);
		
		JEditorPane txtMeu = new JEditorPane();
		txtMeu.setBounds(97, 248, 165, 56);
		frame.getContentPane().add(txtMeu);
		
		JEditorPane txtSupBal = new JEditorPane();
		txtSupBal.setBounds(427, 106, 78, 16);
		frame.getContentPane().add(txtSupBal);
		
		JEditorPane txtSupTer = new JEditorPane();
		txtSupTer.setBounds(441, 166, 87, 23);
		frame.getContentPane().add(txtSupTer);
		
		JEditorPane txtAnCon = new JEditorPane();
		txtAnCon.setBounds(427, 194, 101, 16);
		frame.getContentPane().add(txtAnCon);
		
		JEditorPane txtTyChuf = new JEditorPane();
		txtTyChuf.setBounds(411, 220, 117, 16);
		frame.getContentPane().add(txtTyChuf);
		
		JLabel reChAss = new JLabel("Chemin du ficher de l'attestation assurance:");
		reChAss.setBounds(279, 248, 283, 16);
		frame.getContentPane().add(reChAss);
		
		JTextArea txtChAss = new JTextArea();
		txtChAss.setBounds(279, 278, 334, 42);
		frame.getContentPane().add(txtChAss);
		
		JLabel reChE = new JLabel("Chemin du ficher de l'etat de lieu:");
		reChE.setBounds(24, 323, 225, 16);
		frame.getContentPane().add(reChE);
		
		JTextArea txtChE = new JTextArea();
		txtChE.setBounds(24, 351, 253, 42);
		frame.getContentPane().add(txtChE);
		
		JLabel reIdB = new JLabel("Identifiant du bailleur:");
		reIdB.setBounds(294, 40, 150, 16);
		frame.getContentPane().add(reIdB);
		
		JLabel txtIdB = new JLabel("");
		txtIdB.setBounds(454, 40, 61, 16);
		frame.getContentPane().add(txtIdB);
		
		JComboBox listId = new JComboBox();
		listId.setBounds(145, 36, 137, 20);
		frame.getContentPane().add(listId);
		
		ArrayList<Appartement> list = nwd.getList();
		for (Appartement s : list) {
			listId.addItem(s.getIdBien());
		}
		listId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double id= Double.parseDouble(String.valueOf( listId.getSelectedItem()));
				Appartement app1 = nwd.get(id);
				txtAdr.setText(app1.getAdresse());
				txtEtage.setText(String.valueOf(app1.getEtage()));
				txtNApp.setText(String.valueOf(app1.getNumeroAppartement()));
				txtSupHab.setText(String.valueOf(app1.getSuperficieHabitable()));
				txtNRoom.setText(String.valueOf(app1.getNombreDeChambre()));
				txtMeu.setText(String.valueOf(app1.getIndicateur()));
				txtSupBal.setText(String.valueOf(app1.getSuperficieBalcon()));
				txtSupTer.setText(String.valueOf(app1.getSuperficieTerasse()));
				txtAnCon.setText(String.valueOf(app1.getAnneeDeConstructionDuBatiment()));
				txtTyChuf.setText(String.valueOf(app1.getTypeDeChauffage()));
				txtIdB.setText(String.valueOf(app1.getIdBailleur()));
				txtChE.setText(app1.getEtatDesLieux());
				txtChAss.setText(app1.getAttestationAssurance());
			}					
			});
		JButton botVal = new JButton("Valider");
		botVal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appartement ap = new Appartement(Double.parseDouble(String.valueOf( listId.getSelectedItem())),
						Double.parseDouble(txtIdB.getText()),
						txtAdr.getText(),
						Double.parseDouble(txtSupHab.getText()),
						Double.parseDouble(txtNRoom.getText()),
						txtMeu.getText(),
						ouiBal.isSelected(),
						Double.parseDouble(txtSupBal.getText()),
						ouiTer.isSelected(),
						Double.parseDouble( txtSupTer.getText()),
						Double.parseDouble(txtAnCon.getText()),
						txtTyChuf.getText(),
						txtChAss.getText(),
						txtChE.getText(),
						Double.parseDouble(txtEtage.getText()),
						Double.parseDouble(txtNApp.getText()));
				AppartementDAO nwd= new AppartementDAO();
				String mess = nwd.update(ap);
				JOptionPane.showMessageDialog(new JFrame(),mess,"Resultat",JOptionPane.PLAIN_MESSAGE);
				
				
			}
		});
		botVal.setBounds(496, 379, 117, 29);
		frame.getContentPane().add(botVal);
		

		

		

	}
}