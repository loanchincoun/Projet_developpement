package Interfaces_graphiques;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import Classes.Locataire;
import Dao.Locataire_dao;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Supprimer_locataire {

	public JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Supprimer_locataire window = new Supprimer_locataire();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Supprimer_locataire() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 12));
		frame.getContentPane().setBackground(SystemColor.info);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("New label");
		label.setIcon(new ImageIcon(Supprimer_locataire.class.getResource("/images/logo_1.jpg")));
		label.setBounds(10, 7, 100, 94);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("Veuillez entrez l'identifiant du locataire à supprimer");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(69, 111, 333, 28);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(133, 162, 159, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnValider = new JButton("Valider");
		btnValider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id;
				id=Integer.parseInt(textField.getText());
				Locataire_dao l1= new Locataire_dao();
				l1.delete(id);
				frame.dispose();
			}
		});
		btnValider.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnValider.setBounds(156, 203, 100, 21);
		frame.getContentPane().add(btnValider);
	}
}
