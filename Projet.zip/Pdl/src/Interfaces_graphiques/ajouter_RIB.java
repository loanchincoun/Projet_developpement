package Interfaces_graphiques;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import Dao.Personne_dao;

public class ajouter_RIB {

	public JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ajouter_RIB window = new ajouter_RIB();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	} 

	/**
	 * Create the application.
	 */
	public ajouter_RIB() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("New label");
		label.setIcon(new ImageIcon(ajouter_RIB.class.getResource("/images/logo_1.jpg")));
		label.setBounds(10, 10, 102, 91);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("Ajouter un RIB");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(198, 47, 127, 21);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton btnAjouterrib = new JButton("Ajouter_rib");
				btnAjouterrib.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						JFileChooser fileChooser = new JFileChooser();
				        fileChooser.setDialogTitle("Sélectionnez un fichier");
				        fileChooser.setAcceptAllFileFilterUsed(false);
				        FileNameExtensionFilter filter = new FileNameExtensionFilter("PDF Documents", "pdf");
				        fileChooser.addChoosableFileFilter(filter);
				        FileNameExtensionFilter filters = new FileNameExtensionFilter("Fichiers texte", "txt");
				        fileChooser.addChoosableFileFilter(filters);
		 
				        int returnValue = fileChooser.showOpenDialog(null);
				        if (returnValue == JFileChooser.APPROVE_OPTION) {
				            File selectedFile = fileChooser.getSelectedFile();
				            // Vous pouvez maintenant utiliser 'selectedFile' pour lire le fichier PDF et l'insérer dans la base de données
				            Path pdfPath = Paths.get(selectedFile.getAbsolutePath());
					        try {
					        	byte[] pdfData = Files.readAllBytes(pdfPath);
					        	int id;
								id=Integer.parseInt(textField.getText());
								Personne_dao.addRIB(id, pdfData);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
				        }
					}
				});
				btnAjouterrib.setFont(new Font("Tahoma", Font.PLAIN, 12));
				btnAjouterrib.setBounds(234, 200, 103, 21);
				frame.getContentPane().add(btnAjouterrib);
			}
		});
		btnAjouter.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAjouter.setBounds(198, 162, 85, 21);
		frame.getContentPane().add(btnAjouter);
		
		textField = new JTextField();
		textField.setBounds(245, 112, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Id");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(190, 114, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
