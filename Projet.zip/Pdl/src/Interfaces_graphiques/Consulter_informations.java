package Interfaces_graphiques;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import Dao.Personne_dao;
import Classes.Personne;
import javax.swing.JPanel;

public class Consulter_informations {

	public JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Consulter_informations window = new Consulter_informations();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Consulter_informations() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(SystemColor.info);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Consulter_informations.class.getResource("/images/logo_1.jpg")));
		lblNewLabel.setBounds(10, 10, 99, 100);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Consulter informations ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(209, 54, 181, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Donnez l'identifiant :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(79, 133, 127, 22);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(226, 136, 114, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Valider");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id;
				id=Integer.parseInt(textField.getText()); 
				Personne_dao p1= new Personne_dao();
				Personne p2= p1.get(id);
				
				frame = new JFrame();
				frame.getContentPane().setForeground(SystemColor.info);
				frame.setBounds(100, 100, 450, 300);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.getContentPane().setLayout(null);
				
				JLabel lblNewLabel = new JLabel(p2.getNom());
				lblNewLabel.setBounds(10, 10, 91, 87); 
				frame.getContentPane().add(lblNewLabel);
				
				JLabel lblNewLabel_1 = new JLabel(p2.getPrenom());
				lblNewLabel_1.setBounds(168, 92, 58, 20);
				frame.getContentPane().add(lblNewLabel_1);
				
				JLabel lblNewLabel_2 = new JLabel(p2.getNumeroTel());
				lblNewLabel_2.setBounds(168, 121, 45, 13);
				frame.getContentPane().add(lblNewLabel_2);
				
				JLabel lblNewLabel_3 = new JLabel(p2.getMail());
				lblNewLabel_3.setBounds(169, 144, 45, 13);
				frame.getContentPane().add(lblNewLabel_3);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(166, 198, 85, 21);
		frame.getContentPane().add(btnNewButton);
	}
	

}
