package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Classes.Bailleur;;

public class Bailleur_dao extends ConnectionDAO_PDL {
	
	public Bailleur_dao() {
		super();
	}
	/**
	 * Permet d'ajouter un Locataire dans la table supplier.
	 * Le mode est auto-commit par defaut : chaque insertion est validee
	 * 
	 * @param personne le loctaire a ajouter
	 * @return retourne le nombre de lignes ajoutees dans la table
	 */
	public int add(Bailleur personne  ) {
		Connection con = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO personne_3(Idpersonne, Nom, Prenom, Numero, Mail, Piece_identite, Rib) VALUES(?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, personne.getId());
			ps.setString(2, personne.getNom());
			ps.setString(3, personne.getPrenom());
			ps.setString(4, personne.getNumeroTel());
			ps.setString(5, personne.getMail());
			ps.setBytes(6, personne.getPiece_identite());
			ps.setBytes(7, personne.getRib());
			
			
			ps1 = con.prepareStatement("INSERT INTO Bailleur_3(idpersonne) VALUES(?");
			ps1.setInt(1, personne.getId());
			// Execution de la requete
			returnValue = ps.executeUpdate();
			returnValue = ps1.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de fournisseur existe dÃ©jÃ . Ajout impossible !");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	/**
	 * Permet de supprimer un Locataire par id dans la table supplier.
	 * Si ce dernier possede des articles, la suppression n'a pas lieu.
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param id l'id du locataire à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	
	public int delete(int id) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'ID
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'ID du fournisseur
			ps = con.prepareStatement("DELETE FROM Bailleur_3 WHERE id = ?");
			ps.setInt(1, id);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-02292"))
				System.out.println("Ce bailleur possede des articles, suppression impossible !"
						         + " Supprimer d'abord ses articles ou utiiser la méthode de suppression avec articles.");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				} 
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	 
	/**
	 * Permet d'ajouter un RIB s'il n'y en a pas dans la table
	 * bailleur et le modifie sinon. Le mode est auto-commit par defaut : chaque
	 * insertion est validee
	 *
	 * @param bllr_id_bailleur du bailleur
	 * @param pdfData le fichier en byte à mettre dans la base de donées
	 * @return retourne le nombre de lignes ajoutees dans la table bailleur
	 */
	public static int addRIB(int id_bailleur, byte[] pdfData) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;
 
		// connexion a la base de donnees
		try {
 
			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE personne_3 SET RIB = ? WHERE Idpersonne = ?");
			ps.setBytes(1, pdfData);
			ps.setInt(2, id_bailleur);
 
			// Execution de la requête
			returnValue = ps.executeUpdate();
			
			JOptionPane.showMessageDialog(new JFrame(), "Fichier ajouté ", "Dépôt de fichier",
					JOptionPane.OK_OPTION);
 
		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				JOptionPane.showMessageDialog(new JFrame(), "Ce fichier existe déjà. Ajout impossible !", "Erreur",
						JOptionPane.ERROR_MESSAGE);
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
}
