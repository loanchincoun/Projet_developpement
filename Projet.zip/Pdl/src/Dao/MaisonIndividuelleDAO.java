package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import model.MaisonIndividuelle;


public class MaisonIndividuelleDAO extends ConnectionDAO_PDL{


	public MaisonIndividuelleDAO() 

	{

		super();

	}

	

	/**

	 * Permet d'ajouter un fournisseur dans la table supplier.

	 * Le mode est auto-commit par defaut : chaque insertion est validee

	 * 

	 * @param supplier le fournisseur a ajouter

	 * @return retourne le nombre de lignes ajoutees dans la table

	 */

	public String add(MaisonIndividuelle app) {
		Connection con = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		PreparedStatement ps6 = null;
		PreparedStatement ps7 = null;
		String returnV="";
		int returnValue[]= new int[7];

		returnValue[0]=0;
		returnValue[1]=0;
		returnValue[2]=0;
		returnValue[3]=0;
		returnValue[4]=0;
		returnValue[5]=0;
		returnValue[6]=0;



		// connexion a la base de donnees

		try {

			// tentative de connexion

			con = DriverManager.getConnection(URL, LOGIN, PASS);

			// preparation de l'instruction SQL, chaque ? represente une valeur

			// a communiquer dans l'insertion.

			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps1 = con.prepareStatement("INSERT INTO BIEN_3(idBien,superficieHabitable,nombreChambre,indicateurMeuble,anneeConstruction,typeChauffage,adresse,idbailleur,path_attestationAssurance,path_etatLieux) VALUES(?,?,?,?,?,?,?,?,?,?)");

			ps1.setDouble(1, app.getIdBien());
			ps1.setDouble(2, app.getSuperficieHabitable());
			ps1.setDouble(3, app.getNombreDeChambre());
			ps1.setString(4, app.getIndicateur());
			ps1.setDouble(5, app.getAnneeDeConstructionDuBatiment());
			ps1.setString(6, app.getTypeDeChauffage());
			ps1.setString(7, app.getAdresse());
			ps1.setDouble(8, app.getIdBailleur());
			ps1.setString(9, app.getAttestationAssurance());
			ps1.setString(10, app.getEtatDesLieux());
			
			ps2 = con.prepareStatement("INSERT INTO maisonindividuelle_3(idBien,cave,soussol) VALUES(?,?,?)");
			ps2.setDouble(1, app.getIdBien());
			ps2.setBoolean(2, app.isCave());
			ps2.setBoolean(3, app.isSousSol());
			
			ps3 = con.prepareStatement("INSERT INTO TERASSE_3(idBien,indicateur,SuperficieTerasse) VALUES(?,?,?)");
			ps3.setDouble(1, app.getIdBien());
			ps3.setBoolean(2, app.isTerasse());
			ps3.setDouble(3, app.getSuperficieTerasse());
			
			ps4 = con.prepareStatement("INSERT INTO BALCON_3(idBien,indicateur,SuperficieBalcon) VALUES(?,?,?)");
			ps4.setDouble(1, app.getIdBien());
			ps4.setBoolean(2, app.isBalcon());
			ps4.setDouble(3, app.getSuperficieBalcon());
			
			ps5 = con.prepareStatement("INSERT INTO jardin_3(idBien,indicateur,SuperficieJardin) VALUES(?,?,?)");
			ps5.setDouble(1, app.getIdBien());
			ps5.setBoolean(2, app.isJardin());
			ps5.setDouble(3, app.getSuperficieJardin());
			
			ps6 = con.prepareStatement("INSERT INTO cour_3(idBien,indicateur,SuperficieCour) VALUES(?,?,?)");
			ps6.setDouble(1, app.getIdBien());
			ps6.setBoolean(2, app.isCour());
			ps6.setDouble(3, app.getSuperficieCour());
			
			ps7 = con.prepareStatement("INSERT INTO terrain_3(idBien,indicateur,SuperficieTerrain) VALUES(?,?,?)");
			ps7.setDouble(1, app.getIdBien());
			ps7.setBoolean(2, app.isTerrain());
			ps7.setDouble(3, app.getSuperficieTerrain());
			
			// Execution de la requete
			returnValue[0]=ps1.executeUpdate();
			returnValue[1]=ps2.executeUpdate();
			returnValue[2]=ps3.executeUpdate();
			returnValue[3]=ps4.executeUpdate();
			returnValue[4]=ps5.executeUpdate();
			returnValue[5]=ps6.executeUpdate();
			returnValue[6]=ps7.executeUpdate();
			}
		catch (Exception e) {
			if (e.getMessage().contains("ORA-00001")) {
				System.out.println("Cette appartement existe deja . Ajout impossible !");
			}
			else {
				e.printStackTrace();
				}
			} 
		finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps1 != null) {
					ps1.close();
				}
				if (ps2 != null) {
					ps2.close();
				}
				if (ps3 != null) {
					ps3.close();
				}
				if (ps4 != null) {
					ps4.close();
				}
				if (ps5 != null) {
					ps5.close();
				}
				if (ps6 != null) {
					ps6.close();
				}
				if (ps7 != null) {
					ps7.close();
				}
			}
			catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} 
			catch (Exception ignore) {
			}
		}
		returnV=returnValue[0]+ ","+ returnValue[1]+ ","+ returnValue[2]+ ","+ returnValue[3]+ ","+ returnValue[4]+ ","+ returnValue[5]+ ","+ returnValue[6];	
		return returnV;
	}

	/**
	 * Permet de modifier un fournisseur dans la table supplier.
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * 
	 * @param supplier le fournisseur a modifier
	 * @return retourne le nombre de lignes modifiees dans la table
	 */
	public String update(MaisonIndividuelle app) {
		Connection con = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		PreparedStatement ps6 = null;
		PreparedStatement ps7 = null;
		String returnV="";
		int returnValue[]= new int[7];

		returnValue[0]=0;
		returnValue[1]=0;
		returnValue[2]=0;
		returnValue[3]=0;
		returnValue[4]=0;
		returnValue[5]=0;
		returnValue[6]=0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			//BIEN_3(idBien,superficieHabitable,nombreChambre,indicateurMeuble,anneeConstruction,
			//typeChauffage,adresse,path_attestationAssurance,path_etatLieux) VALUES(?,?,?,?,?,?,?,?,?)")
			ps1 = con.prepareStatement("UPDATE bien_3 set  superficieHabitable= ?, nombreChambre = ?, indicateurMeuble = ?,anneeConstruction= ?,typeChauffage= ?,adresse= ?,idBailleur = ?, path_attestationAssurance= ?,path_etatLieux= ? WHERE idBien = ?");
			ps1.setDouble(1, app.getSuperficieHabitable());
			ps1.setDouble(2, app.getNombreDeChambre());
			ps1.setString(3, app.getIndicateur());
			ps1.setDouble(4, app.getAnneeDeConstructionDuBatiment());
			ps1.setString(5, app.getTypeDeChauffage());
			ps1.setString(6, app.getAdresse());
			ps1.setDouble(7, app.getIdBailleur());
			ps1.setString(8, app.getAttestationAssurance());
			ps1.setString(9, app.getEtatDesLieux());
			ps1.setDouble(10, app.getIdBien());
	
			ps2 = con.prepareStatement("UPDATE appartement_3 set  cave= ?,soussol= ? WHERE idBien = ?");
			ps2.setBoolean(1, app.isCave());
			ps2.setBoolean(2, app.isSousSol());
			ps2.setDouble(3, app.getIdBien());
	
			ps3 = con.prepareStatement("UPDATE terasse_3 set  indicateur= ?,superficieterasse= ? WHERE idBien = ?");
			ps3.setBoolean(1, app.isTerasse());
			ps3.setDouble(2, app.getSuperficieTerasse());
			ps3.setDouble(3, app.getIdBien());

			ps4 = con.prepareStatement("UPDATE balcon_3 set  indicateur = ?,superficiebalcon = ? WHERE idBien = ?");
			ps4.setBoolean(1, app.isBalcon());
			ps4.setDouble(2, app.getSuperficieBalcon());
			ps4.setDouble(3, app.getIdBien());
			
			
			ps5 = con.prepareStatement("UPDATE jardin_3 set  indicateur= ?,SuperficieJardin= ?  WHERE idBien = ?");
			ps5.setDouble(2, app.getSuperficieJardin());
			ps5.setDouble(3, app.getIdBien());
			ps5.setBoolean(1, app.isJardin());
			
			ps6 = con.prepareStatement("UPDATE cour_3 set  indicateur= ?,SuperficieCour= ? WHERE idBien = ?");
			ps6.setBoolean(1, app.isCour());
			ps6.setDouble(2, app.getSuperficieCour());
			ps6.setDouble(3, app.getIdBien());
			
			ps7 = con.prepareStatement("UPDATE terrain_3 set indicateur= ?,SuperficieTerrain= ?  WHERE idBien = ?");
			ps7.setBoolean(1, app.isTerrain());
			ps7.setDouble(2, app.getSuperficieTerrain());
			ps7.setDouble(3, app.getIdBien());

			// Execution de la requete
			returnValue[0]=ps1.executeUpdate();
			returnValue[1]=ps2.executeUpdate();
			returnValue[2]=ps3.executeUpdate();
			returnValue[3]=ps4.executeUpdate();
			returnValue[4]=ps5.executeUpdate();
			returnValue[5]=ps6.executeUpdate();
			returnValue[6]=ps7.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps1 != null) {
					ps1.close();
				}
				if (ps2 != null) {
					ps2.close();
				}
				if (ps3 != null) {
					ps3.close();
				}
				if (ps4 != null) {
					ps4.close();
				}
				if (ps5 != null) {
					ps5.close();
				}
				if (ps6 != null) {
					ps6.close();
				}
				if (ps7 != null) {
					ps7.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnV;
	}
	
	/**
	 * Permet de supprimer un fournisseur par id dans la table supplier.
	 * Si ce dernier possede des articles, la suppression n'a pas lieu.
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param id l'id du supplier à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	public int delete(double id) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'ID
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'ID du bien
			ps = con.prepareStatement("DELETE FROM bien_3 WHERE idbien = ?");
			ps.setDouble(1, id);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-02292"))
				System.out.println("Ce fournisseur possede des articles, suppression impossible !"
						         + " Supprimer d'abord ses articles ou utiiser la méthode de suppression avec articles.");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * Permet de recuperer un fournisseur a partir de sa reference
	 * 
	 * @param reference la reference du fournisseur a recuperer
	 * @return le fournisseur trouve;
	 * 			null si aucun fournisseur ne correspond a cette reference
	 */
	public MaisonIndividuelle get(double id) {
		Connection con = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		PreparedStatement ps6 = null;
		PreparedStatement ps7 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		ResultSet rs5 = null;
		ResultSet rs6 = null;
		ResultSet rs7 = null;
		MaisonIndividuelle returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps1 = con.prepareStatement("SELECT * FROM bien_3 WHERE idbien = ?");
			ps1.setDouble(1, id);
			ps2 = con.prepareStatement("SELECT * FROM maisonindividuelle_3 WHERE idbien = ?");
			ps2.setDouble(1, id);
			ps3 = con.prepareStatement("SELECT * FROM terasse_3 WHERE idbien = ?");
			ps3.setDouble(1, id);
			ps4 = con.prepareStatement("SELECT * FROM balcon_3 WHERE idbien = ?");
			ps4.setDouble(1, id);
			ps5 = con.prepareStatement("SELECT * FROM jardin_3 WHERE idbien = ?");
			ps5.setDouble(1, id);
			ps6 = con.prepareStatement("SELECT * FROM cour_3 WHERE idbien = ?");
			ps6.setDouble(1, id);
			ps7 = con.prepareStatement("SELECT * FROM terrain_3 WHERE idbien = ?");
			ps7.setDouble(1, id);


			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs1 = ps1.executeQuery();
			rs2 = ps2.executeQuery();
			rs3 = ps3.executeQuery();
			rs4 = ps4.executeQuery();
			rs5 = ps5.executeQuery();
			rs6 = ps6.executeQuery();
			rs7 = ps7.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			//double idBien, String adresse,
			//double superficieHabitable, double nombreDeChambre, String indicateur, boolean balcon,
			//double superficieBalcon, boolean terasse, double superficieTerasse, double anneeDeConstructionDuBatiment,
			//String typeDeChauffage, String attestationAssurance, String etatDesLieux,boolean escalier,double etage,
			//double numeroAppartement
		
			if (rs1.next() && rs2.next() && rs3.next() && rs4.next()&& rs5.next() &&rs6.next() && rs7.next() ) {
				returnValue = new MaisonIndividuelle(rs1.getDouble(1),
											rs1.getDouble(8),
									       rs1.getString(7),
									       rs1.getDouble(2),
									       rs1.getDouble(3),
									       rs1.getString(4),
									       rs4.getBoolean(2),
									       rs4.getDouble(3),
									       rs3.getBoolean(2),
									       rs3.getDouble(3),
									       rs1.getDouble(5),
									       rs1.getString(6),
									       rs1.getString(9),
									       rs1.getString(10),
									       rs2.getBoolean(2),
									       rs2.getBoolean(3),
									       rs5.getBoolean(2),
									       rs5.getDouble(3),
									       rs7.getBoolean(2),
									       rs7.getDouble(3),
									       rs6.getBoolean(2),
									       rs6.getDouble(3)
									       );
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs1 != null) {
					rs1.close();
				}
				if (rs2 != null) {
					rs2.close();
				}
				if (rs3 != null) {
					rs3.close();
				}
				if (rs4 != null) {
					rs4.close();
				}
				if (rs5 != null) {
					rs5.close();
				}
				if (rs6 != null) {
					rs6.close();
				}
				if (rs7 != null) {
					rs7.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps1 != null) {
					ps1.close();
				}
				if (ps2 != null) {
					ps2.close();
				}
				if (ps3 != null) {
					ps3.close();
				}
				if (ps4 != null) {
					ps4.close();
				}
				if (ps5 != null) {
					ps5.close();
				}
				if (ps6 != null) {
					ps6.close();
				}
				if (ps7 != null) {
					ps7.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de recuperer tous les fournisseurs stockes dans la table fournisseur
	 * 
	 * @return une ArrayList de fournisseur
	 */
	public ArrayList<MaisonIndividuelle> getList() {
		Connection con = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		PreparedStatement ps6 = null;
		PreparedStatement ps7 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		ResultSet rs5 = null;
		ResultSet rs6 = null;
		ResultSet rs7 = null;
		ArrayList<MaisonIndividuelle> returnValue = new ArrayList<MaisonIndividuelle>();

		// connexion a la base de donnees
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps1 = con.prepareStatement("SELECT * FROM bien_3 ORDER BY idbien");
			ps2 = con.prepareStatement("SELECT * FROM maisonindividuelle_3 ORDER BY idbien");
			ps3 = con.prepareStatement("SELECT * FROM terasse_3 ORDER BY idbien");
			ps4 = con.prepareStatement("SELECT * FROM balcon_3 ORDER BY idbien");
			ps5 = con.prepareStatement("SELECT * FROM jardin_3 ORDER BY idbien");
			ps6 = con.prepareStatement("SELECT * FROM cour_3 ORDER BY idbien");
			ps7 = con.prepareStatement("SELECT * FROM terrain_3 ORDER BY idbien");

			// on execute la requete
			rs1 = ps1.executeQuery();
			rs2 = ps2.executeQuery();
			rs3 = ps3.executeQuery();
			rs4 = ps4.executeQuery();
			rs5 = ps5.executeQuery();
			rs6 = ps6.executeQuery();
			rs7 = ps7.executeQuery();
			// on parcourt les lignes du resultat
			while (rs1.next() && rs2.next() && rs3.next() && rs4.next()&& rs5.next() &&rs6.next() && rs7.next()) {
				returnValue.add(new MaisonIndividuelle(rs1.getDouble(1),
						rs1.getDouble(8),
					       rs1.getString(7),
					       rs1.getDouble(2),
					       rs1.getDouble(3),
					       rs1.getString(4),
					       rs4.getBoolean(2),
					       rs4.getDouble(3),
					       rs3.getBoolean(2),
					       rs3.getDouble(3),
					       rs1.getDouble(5),
					       rs1.getString(6),
					       rs1.getString(9),
					       rs1.getString(10),
					       rs2.getBoolean(2),
					       rs2.getBoolean(3),
					       rs5.getBoolean(2),
					       rs5.getDouble(3),
					       rs7.getBoolean(2),
					       rs7.getDouble(3),
					       rs6.getBoolean(2),
					       rs6.getDouble(3)));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs1 != null) {
					rs1.close();
				}
				if (rs2 != null) {
					rs2.close();
				}
				if (rs3 != null) {
					rs3.close();
				}
				if (rs4 != null) {
					rs4.close();
				}
				if (rs5 != null) {
					rs5.close();
				}
				if (rs6 != null) {
					rs6.close();
				}
				if (rs7 != null) {
					rs7.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps1 != null) {
					ps1.close();
				}
				if (ps2 != null) {
					ps2.close();
				}
				if (ps3 != null) {
					ps3.close();
				}
				if (ps4 != null) {
					ps4.close();
				}
				if (ps5 != null) {
					ps5.close();
				}
				if (ps6 != null) {
					ps6.close();
				}
				if (ps7 != null) {
					ps7.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	

	
	public static void main(String[] args) throws SQLException {
		String returnValue;
		MaisonIndividuelleDAO appDAO = new MaisonIndividuelleDAO();
		// Ce test va utiliser directement votre BDD, on essaie d'éviter les collisions avec vos données en prenant de grands ID
		int[] ids = {427, 525, 626};
		// test du constructeur
		MaisonIndividuelle app1 = new MaisonIndividuelle(ids[0] ,11, "3 rue burbon,Rouen 45000",18,1, "table",true,2,false,0,2003,"chaud","assurance1","lieux5",true,false,true,20,false,0,false,0);
		MaisonIndividuelle app2 = new MaisonIndividuelle(ids[1], 11, "5 boulevard,Havre 53000",14,1,"lampe",false,0,true,3,1963,"froid","assurance2","lieux6",true,false,true,20,false,0,false,0);
		MaisonIndividuelle app3 = new MaisonIndividuelle(ids[2],11, "4 avenue, Paris 76000 ",30,2,"armoire",false,0,false,0,1996,"bof","assurance3","lieux7",true,false,true,20,false,0,false,0);
		// test de la methode add

		returnValue = appDAO.add(app1);
		System.out.println(returnValue + " fournisseur ajoute");
		returnValue = appDAO.add(app2);
		System.out.println(returnValue + " fournisseur ajoute");
		returnValue = appDAO.add(app3);
		System.out.println(returnValue + " fournisseur ajoute");
		System.out.println();
		
	}
}
