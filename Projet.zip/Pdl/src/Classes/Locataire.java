package Classes;

public class Locataire extends Personne{

	public Locataire(String nom, String prenom, String numeroTel, String mail, int id, byte[] piece_identite,
			byte[] rib) {
		super(nom, prenom, numeroTel, mail, id, piece_identite, rib);
		// TODO Auto-generated constructor stub
	}
	
}
