package Classes;

public class Authentification {
	private String motPasse;
	private String nomUtilisateur;
	
	public Authentification(String motPasse, String nomUtilisateur) {
		this.motPasse = motPasse;
		this.nomUtilisateur = nomUtilisateur;
	}

	public String getMotPasse() {
		return motPasse;
	}

	public String getNomUtilisateur() {
		return nomUtilisateur;
	}

	public void setMotPasse(String motPasse) {
		this.motPasse = motPasse;
	}

	public void setNomUtilisateur(String nomUtilisateur) {
		this.nomUtilisateur = nomUtilisateur;
	}

}
