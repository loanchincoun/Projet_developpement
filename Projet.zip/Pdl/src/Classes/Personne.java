package Classes;

public class Personne {
	private String nom;
	private String prenom;
	private String numeroTel;
	private String mail;
	private int id;
	private byte[] piece_identite;
	private byte[] rib;
	
	public Personne(String nom, String prenom, String numeroTel, String mail, int id, byte[] piece_identite,
			byte[] rib) {
		
		this.nom = nom;
		this.prenom = prenom;
		this.numeroTel = numeroTel;
		this.mail = mail; 
		this.id = id;
		this.piece_identite = piece_identite;
		this.rib = rib;
	}
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public String getNumeroTel() {
		return numeroTel;
	}
	public String getMail() {
		return mail;
	}
	public int getId() {
		return id;
	}
	public byte[] getPiece_identite() {
		return piece_identite;
	}
	public byte[] getRib() {
		return rib;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public void setNumeroTel(String numeroTel) {
		this.numeroTel = numeroTel;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setPiece_identite(byte[] piece_identite) {
		this.piece_identite = piece_identite;
	}
	public void setRib(byte[] rib) {
		this.rib = rib;
	}
	
	
	
	
}